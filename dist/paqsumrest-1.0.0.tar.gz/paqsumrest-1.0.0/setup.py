#from setuptools import setup
import setuptools

#with open("README.md", "r") as fh:
#    long_description = fh.read()
#packages=setuptools.find_packages(),
setuptools.setup(
      name="paqsumrest",
      version="1.0.0",
      description="ejemplo de setup inicial2",
      author="mp",
      author_email="mp@mp.com.ar",
      url="www.sarasa.com.ar",
      packages=["libmate"],
      classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
      ]

)