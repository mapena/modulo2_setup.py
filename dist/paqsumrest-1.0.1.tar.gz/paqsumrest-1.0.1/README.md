** python setup.py sdist upload -r nexus **
** name="paqsumrest" **

from libmate.fmathsum import *
       
#print(sumar(2,3)) 
#print(sumar2(2,3)) 