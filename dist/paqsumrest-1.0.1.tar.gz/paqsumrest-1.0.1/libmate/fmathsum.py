def sumar(n1,n2):
    print("version 1.0.0")
    return (n1+n2)

def sumar2(n1,n2):
    print("version 1.0.0")
    return 2*(n1+n2)

def sumar1_0_1(n1,n2):
    print("version 1.0.1")
    return (n1+n2)