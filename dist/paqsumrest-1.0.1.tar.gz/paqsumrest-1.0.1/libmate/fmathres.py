def restar(n1,n2):
    return (abs(n1-n2))